﻿namespace WebApplication1
{
    public interface Interface
    {
    }
}
